from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import razorpay
import os
from dotenv import load_dotenv
from flipkart import scrape_flipkart_deals
from amazon import scrape_amazon_deals

load_dotenv()
app = FastAPI()

# Razorpay Client
razorpay_client = razorpay.Client(auth=(os.getenv("RAZORPAY_KEY_ID"),
                                        os.getenv("RAZORPAY_KEY_SECRET")))


@app.get("/")
def frontend():
    return FileResponse("index.html")


@app.get("/flipkart-deals")
def get_flipkart_deals():
    return scrape_flipkart_deals()


@app.get("/amazon-deals")
def get_amazon_deals():
    return scrape_amazon_deals()


class PaymentRequest(BaseModel):
    amount: int
    deal_id: str
    user_id: str


@app.post("/create_order")
def create_payment(request: PaymentRequest):
    order = razorpay_client.order.create({
        "amount": request.amount,
        "currency": "INR",
        "payment_capture": 1,
        "notes": {
            "deal_id": request.deal_id,
            "user_id": request.user_id
        }
    })
    return {
        "order_id": order['id'],
        "amount": request.amount,
        "deal_id": request.deal_id,
        "user_id": request.user_id,
        "razorpay_key": os.getenv("RAZORPAY_KEY_ID")
    }


app.mount("/static", StaticFiles(directory="."), name="static")
