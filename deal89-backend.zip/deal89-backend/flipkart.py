import requests
from bs4 import BeautifulSoup


def scrape_flipkart_deals():
    url = "https://www.flipkart.com/offers-store"
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, "html.parser")

    deals = []
    for item in soup.select(
            "a._1xHGtK")[:5]:  # Or use fallback mock data if needed
        link = "https://www.flipkart.com" + item.get("href", "")
        title = item.select_one("div._2WkVRV")
        price = item.select_one("div._30jeq3")
        deals.append({
            "title": title.text if title else "No Title",
            "url": link,
            "price": price.text if price else "No Price"
        })
    return deals or [{
        "title": "Mock Deal 1",
        "url": "https://flipkart.com/item1",
        "price": "₹199"
    }, {
        "title": "Mock Deal 2",
        "url": "https://flipkart.com/item2",
        "price": "₹499"
    }]
