import requests
from bs4 import BeautifulSoup


def scrape_amazon_deals():
    url = "https://www.amazon.in/gp/goldbox"
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, "html.parser")

    deals = []
    for deal in soup.select(".DealCard-module__card_1gqDN"):
        title = deal.select_one(
            "span.DealContent-module__truncate_sWbxETx42ZPStTc9jwySW").text
        link = "https://www.amazon.in" + deal.find("a")["href"]
        deals.append({"title": title, "link": link})
    return deals
